from .bumptesttwo import BumpTestTwo


def setup(bot):
    bot.add_cog(BumpTestTwo(bot))
